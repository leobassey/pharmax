<?php
require_once 'dbconfig.php';
//
if($_SERVER['REQUEST_METHOD'] == 'POST')
{
	
if(isset($_POST['add']))
{
	$category = filter_var($_POST['category'], FILTER_SANITIZE_STRING);
	$drugName = filter_var($_POST['drugname'], FILTER_SANITIZE_STRING);
	$unit = filter_var($_POST['unit'], FILTER_SANITIZE_NUMBER_INT);
	$price = filter_var($_POST['price'], FILTER_SANITIZE_NUMBER_INT);

	if(!empty($category) && !empty($drugName) && !empty($unit) && !empty($price))
	{

	$insertStatement = $db_connection->prepare('INSERT INTO drugs(Category, DrugName, Unit, Price)VALUES(:Category, :DrugName, :Unit, :Price)');
	$insertStatement->bindValue(':Category', $category, PDO::PARAM_STR);
	$insertStatement->bindValue(':DrugName', $drugName, PDO::PARAM_STR);
	$insertStatement->bindValue(':Unit', $unit, PDO::PARAM_INT);
	$insertStatement->bindValue(':Price', $price, PDO::PARAM_INT);

	if($insertStatement->execute())
	{
			?>
                <script>
				alert('drug added successfully');
				window.location.href='adddrug2.php';
				</script>
                <?php 
	}
	else
	{
			?>
                <script>
				alert('Error adding drug please try again');
				window.location.href='adddrug2.php';
				</script>
                <?php
	}

	}
	else
	{
			?>
                <script>
				alert('Error adding drug.... Please ensure that all form fields are filled properly and try again');
				window.location.href='adddrug.html';
				</script>
                <?php
	}


	
}

}
else
{
	?>
	<script>
	alert('Invalid request');
	window.location.href='adddrug2.php';
	</script>
	<?php
}
?>