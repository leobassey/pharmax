<?php
require_once 'dbconfig.php';
$getDate;
function conn ()
{

		$db_host = 'localhost';
		$db_user = 'root';
		$db_password = '';
		$db_name = 'pharmaxdb';

		try
		{
			$db_connection = new PDO("mysql:host={$db_host};dbname={$db_name}", $db_user, $db_password);
			$db_connection-> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

		}
		catch(PDOEXCEPTION $e)
		{
			echo $e->getMessage();
		}

		return $db_connection;
}
if(isset($_POST['report']))
{
	$getDate = $_POST['txtdate'];
}

function getFinal()
{
	$con = conn();
    $fetchCart =  $con->prepare("select * from finalsales where date =:date");
	$fetchCart->bindValue(":date", $_POST['txtdate']);
	$fetchCart->execute();
	$fullRows = $fetchCart->fetchAll(PDO::FETCH_ASSOC);
	return $fullRows;
}

?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/admin.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" href="http://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">

 <style type="text/css">

 </style>

</head>
<!--header should be included here-->
<?php
include('../pharmax/views/header.php')
 ?>

<div id="wrapper">
<!--left side bar should be included here-->
<?php
include('../pharmax/views/leftsidebar.php')
 ?>

<div id="contents">

<?php
$fetchR = getFinal();
//$InvoiceNo = $fetchR[0]["InvoiceNo"];
$grandtotal = 0
?>

		<table class="table table-bordered">
		<tr><th>Drug Name</th><th>Price</th><th>Quantity</th><th>Total</th><th>Date</th></tr>
		<?php foreach ($fetchR as $one) {
		$grandtotal = $grandtotal + $one["Total"] ?>
		<tr>
		<td><?php echo $one["DrugName"];?></td>
		<td><?php echo $one["Price"];?></td>
		<td><?php echo $one["Quantity"];?></td>
		<td><?php echo $one["Total"];?></td>
		<td><?php echo $one["date"];?></td>
		
		</tr>



	<?php } ?>

</table>
<h2>Total Sales for the day: N<?php  echo $grandtotal; ?></h2>

</div>

</div>

<script  src="js/jquery-3.1.1.min.js"></script>
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
