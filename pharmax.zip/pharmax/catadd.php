<?php
require_once 'dbconfig.php';
//
if($_SERVER['REQUEST_METHOD'] == 'POST')
{
	
if(isset($_POST['catadd']))
{
	$catName = filter_var($_POST['catname'], FILTER_SANITIZE_STRING);
	

	if(!empty($catName))
	{

	$insertStatement = $db_connection->prepare('INSERT INTO category(Name)VALUES(:Name)');
	$insertStatement->bindValue(':Name', $catName, PDO::PARAM_STR);
	
	if($insertStatement->execute())
	{
			?>
                <script>
				alert('category added successfully');
				window.location.href='adddrug2.php';
				</script>
                <?php 
	}
	else
	{
			?>
                <script>
				alert('Error adding category please try again');
				window.location.href='adddrug2.php';
				</script>
                <?php
	}

	}
	else
	{
			?>
                <script>
				alert('Error adding category.... Please ensure that all form fields are filled properly and try again');
				window.location.href='adddrug2.php';
				</script>
                <?php
	}


	
}

}
else
{
	?>
	<script>
	alert('Invalid request');
	window.location.href='adddrug2.php';
	</script>
	<?php
}
?>