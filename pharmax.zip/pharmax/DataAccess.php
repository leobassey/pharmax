<?php

class DataAccess
{

  //Database connection parameters
  private $server = "mysql:dbname=pharmaxdb;host=localhost";
  private $db_user = 'root';
  private $db_password = '';
  private $db_connection;

  //Class constructor
  public function __construct()
  {
    $this->db_connection = new PDO($this->server, $this->db_user, $this->db_password);
  }

  public function getConnection()
  {
    return $this->$db_connection;
  }

  public function viewSalesByDateRange($date1, $date2)
  {
    $sql = $this->$db_connection->prepare("select * from finalsales where date between :date1 and :date2");
    $sql->bindValue(":date1", $date1, PDO::PARAM_DATE);
    $sql->bindValue(":date2", $date2, PDO::PARAM_DATE);
    $sql->excute();
    return $sql->fetchAll(PDO::FECH_ASSOC);
  }

}
