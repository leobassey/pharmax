<div id="footer">pharmaX (c) 2017. All right reserved. Powered by <a href="#">Memdal Solutions</a></div>
