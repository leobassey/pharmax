<script>
function help()
{

	alert('Please contact the system administration');
}
</script>
<div id="contact-container">
<div class="logo">PharmaX</div>

<div class="search">

<input type="text" id="txtSearch" name="txtSearch" class="txsearch" placeholder="Search">
<button type="" class="bb">Search</button>

</div>

<div class="contact-links">
<ul>
<!--<li><a href="#">About </a></li>-->
<li><a href="#" onclick="help()">Help </a></li>
<!--<li><a href="#">Contact </a></li>-->
</ul>
</div>
</div>
