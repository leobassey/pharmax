<div class="calculator">
<div id="sec">Swift Calculator</div>

<br>

<form onsubmit="javascript:cal(document.getElementById('valueshow').value);return false;" class="calculator">
<table align="center">
<tr>
<td colspan="4"><input id="valueshow" type="text" value="0" class="inputc"></td>
</tr>
<tr>
<td><input class="bgcolornumber" type="button" value=1 onClick="cals(this.value);"></td>
<td><input class="bgcolornumber"  type="button" value=2 onClick="cals(this.value);"></td>
<td><input class="bgcolornumber"  type="button" value=3 onClick="cals(this.value);"></td>
<td><input class="bgoperationcolor" type="button" value='/' onClick="cals(this.value);"></td>
</tr>
<tr>
<td><input class="bgcolornumber" type="button" value=4 onClick="cals(this.value);"></td>
<td><input class="bgcolornumber" type="button" value=5 onClick="cals(this.value);"></td>
<td><input class="bgcolornumber" type="button" value=6 onClick="cals(this.value);"></td>
<td><input class="bgoperationcolor" type="button" value='x' onClick="cals('*');"></td>
</tr>
<tr>
<td><input class="bgcolornumber" type="button" value=7 onClick="cals(this.value);"></td>
<td><input class="bgcolornumber" type="button" value=8 onClick="cals(this.value);"></td>
<td><input class="bgcolornumber" type="button" value=9 onClick="cals(this.value);"></td>
<td><input class="bgoperationcolor" type="button" value='-' onClick="cals(this.value);"></td>
</tr>
<tr>
<td><input class="bgcolornumber" type="button" value=0 onClick="cals(this.value);"></td>
<td><input class="bgcolornumber" type="button" value='.' onClick="cals(this.value);"></td>
<td><input class="bgclear" type="button" value='C' onClick="cals(this.value);"></td>
<td><input class="bgoperationcolor" type="button" value='+' onClick="cals(this.value);"></td>
</tr>
<tr>
<td colspan="4">
<input type="button" class="equal" value='=' onClick="cal(document.getElementById('valueshow').value);">
</td>
</tr>
</table>
</form>

</div>
