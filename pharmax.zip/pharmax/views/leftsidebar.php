<div id="left-links">

<div id="sec">Pharmacy</div>

<ul id="stories">
<a href="adddrug2.php"><img src="css/icons/target.png" class="ico">Add Drugs</a>
<a href="viewdrug.php"><img src="css/icons/settings.png" class="ico">Manage Drugs</a>
<a href="sales.php"><img src="css/icons/onebit_24.png" class="ico">Sales Entry</a>
<!--<a href=""><img src="css/icons/search-btn.gif" class="ico">Search</a>-->
<a href="report.php"><img src="css/icons/reports.png" class="ico">Sales Report</a>
<a href="login.html"><img src="css/icons/reports.png" class="ico">Logout</a>
</ul>
<!--
<div id="sec">User Account</div>

<ul id="stories">
<a href=""><img src="css/icons/plus.png" class="ico">Create Users</a>
<a href=""><img src="css/icons/group.png" class="ico">Manage Users</a>
<a href=""><img src="css/icons/anchor.png" class="ico">Create Role</a>
<a href=""><img src="css/icons/wheel.png" class="ico">Manage Role</a>
<a href=""><img src="css/icons/funnel.png" class="ico">User Role</a>

</ul>
-->
<!--
<div id="sec">Patient</div>
<ul id="stories">
<a href=""><img src="css/icons/target.png" class="ico">Patient Registration</a>
<a href=""><img src="css/icons/settings.png" class="ico">Manage Patient</a>
<a href=""><img src="css/icons/search-btn.gif" class="ico">Search</a>
<a href=""><img src="css/icons/wheel.png" class="ico">Room Details</a>

</ul>

<div id="sec">Doctor</div>

<ul id="stories">
<a href=""><img src="css/icons/target.png" class="ico">Add Doctor</a>
<a href=""><img src="css/icons/settings.png" class="ico">Manage Doctor</a>
<a href=""><img src="css/icons/search-btn.gif" class="ico">Search</a>

</ul>


-->

</div>
