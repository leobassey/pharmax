
<?php

	require_once 'dbconfig.php';
	if(isset($_GET['DrugId']))
	{
		$stmt_delete = $db_connection->prepare('DELETE FROM drugs WHERE DrugId =:DrugId');
		$stmt_delete->bindParam(':DrugId',$_GET['DrugId']);


		if($stmt_delete->execute())
			{
				?>
                <script>
				alert('Drug deleted successfully');
				window.location.href='viewdrug.php';
				</script>
                <?php
			}
			else
			{
				?>
                <script>
				alert('There was problem deleted record! Please try again later');
				window.location.href='viewdrug.php';
				</script>
                <?php
			}

	}

?>


<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/admin.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">


	<style type="text/css">


input[type="button"]
{ width:100%; height:50px;transition: all 0.3s ease-in-out; transition: all 0.3s ease-in-out;
	border: 1px solid transparent;
	border-radius: 5px;
	margin-left: 4%;
	margin-top: 9px;
	padding: 15px;
	margin: 3px;
	background-color: #f6f8f8;

}
 .inputc
{
	margin-left: 4%;
	border: 1px solid #a8a8a8;
	border-radius: 5px;
	font-size: 30px;
	height: 40px;
	width: 95%;
	color: #a8a8a8;
}
.bgcolornumber{ background-color:#f1f1f1; color:#333; transition: all 0.3s ease-in-out;}
.bgclear{ background:#CC0000; color:#000;transition: all 0.3s ease-in-out;}
.bgoperationcolor{ background-color:#f6f8f8; color:#000; transition: all 0.3s ease-in-out;}
.equal{ background-color:#66CC33; color:#000; transition: all 0.3s ease-in-out;}
.bgcolornumber:hover{ background-color:#222; color:#f5f5f5;transition: all 0.3s ease-in-out;}
.bgclear:hover{background-color:#222; color:#f5f5f5;transition: all 0.3s ease-in-out;}
.bgoperationcolor:hover{ background-color:#222;; color:#f5f5f5;transition: all 0.3s ease-in-out;}
.equal:hover{ background-color:#222; color: #f5f5f5; transition: all 0.3s ease-in-out;}


</style>
<script type="text/javascript">
function cals(buttonValue)
{
if (buttonValue == 'C')
{
   document.getElementById('valueshow').value = '0';
}
else
  {
    if(document.getElementById('valueshow').value == '0')
 {

   document.getElementById('valueshow').value = buttonValue;
}

  else
   {

    document.getElementById('valueshow').value += buttonValue;
   }
  }
 }
  function cal(equation)

  {
  var answer = eval(equation);
document.getElementById('valueshow').value = answer;
 }
 </script>

 <style type="text/css">
 .ps-btn{ border-radius:1px !important;}
 </style>

</head>
<body>


<?php
include('../pharmax/views/header.php')
 ?>

<div id="wrapper">
<?php
include('../pharmax/views/leftsidebar.php')
 ?>

<div id="contents">
<ul>

	<li><img src="css/icons/home.png"><a href="adddrug2.php">&nbsp; Add Drug >></a></li>
	<li><img src="css/icons/Edit.gif"><a href="viewdrug.php">&nbsp;View All </a></li>&nbsp;&nbsp;&nbsp;
	<li><img src="css/icons/settings.png"><a href="viewcategory.php">&nbsp;Edit category </a></li>
</ul>
    <p></p><p></p><p></p><p></p>

<br/><br/>
<p class="pview"> All Drugs</p>

	<br/><br/>

	<?php

			$sql = "SELECT * from drugs";
			$query = $db_connection->prepare($sql);
			$query->execute();
			$results = $query->fetchAll(PDO::FETCH_ASSOC);
	?>

<table class="table table-bordered table-responsive">

	<tr>
			<th >Category</th>
			<th>Drug Name</th>
			<th>Unit inStock</th>
			<th>Price</th>

			<th><strong>Edit</strong></th>
			<th><strong>Delete</strong></th>


	</tr>


 <?php foreach( $results as $row )
 {
 	?>
   		<tr>


     	<td> <?php  echo $row['Category'] ?></td>

     	<td> <?php echo $row['DrugName'];?></td>

     	<td> <?php echo $row['Unit']; ?> </td>

     	<td> <?php echo $row['Price']; ?></td>

       	<td><a href='editdrug.php?DrugId=<?php echo $row["DrugId"]?>' > <img src='css/icons/Edit.gif'> </a></td>

     	<td><a href='viewdrug.php?DrugId=<?php echo $row["DrugId"]?>' > <img src='css/icons/Cancel.gif'> </a></td>

   		</tr>

  <?php
}

 ?>


</table>

</div>
<?php
include('../pharmax/views/rightsidebar.php')
 ?>
</div>
<script src="js/jquery-3.1.1.min.js"></script>

<script src="js/bootstrap.js"></script>
<div id="footer">pharmaX (c) 2017. All right reserved. Powered by <a href="#">Memdal Solutions</a></div>
</body>
</html>
