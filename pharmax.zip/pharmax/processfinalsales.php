<?php
require_once 'dbconfig.php';
function conn ()
{

		$db_host = 'localhost';
		$db_user = 'root';
		$db_password = '';
		$db_name = 'pharmaxdb';

		try
		{
			$db_connection = new PDO("mysql:host={$db_host};dbname={$db_name}", $db_user, $db_password);
			$db_connection-> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

		}
		catch(PDOEXCEPTION $e)
		{
			echo $e->getMessage();
		}

		return $db_connection;
}

function getFinal()
{
	$con = conn();
    $fetchCart =  $con->prepare("select * from finalsales where SessionId =:SessionId");
	$fetchCart->bindValue(":SessionId", $_SESSION["session_id"]);
	$fetchCart->execute();
	$fullRows = $fetchCart->fetchAll(PDO::FETCH_ASSOC);
	return $fullRows;
}

session_start();
  if(!isset($_SESSION["session_id"])){
  	header("location:sales.php");
  }


  function addToFinal($InvoiceNo, $fullRows)
  {
  	 //insert into sales table
  	$con = conn();
	$insert = "Insert into finalsales (DrugId, DrugName,  Price, Quantity, SessionId, Total, date, InvoiceNo) values
	(:DrugId, :DrugName,  :Price, :Quantity, :SessionId, :Total, :Date, :InvoiceNo)";
    $sql = $con->prepare($insert);
	$sql->bindValue(":DrugId", $fullRows["DrugId"], PDO::PARAM_INT);
	$sql->bindValue(":DrugName", $fullRows["DrugName"], PDO::PARAM_STR);
	$sql->bindValue(":Price", $fullRows["Price"], PDO::PARAM_INT);
	$sql->bindValue(":Quantity", $fullRows["Quantity"], PDO::PARAM_INT);
	$sql->bindValue(":SessionId",  $_SESSION["session_id"]  , PDO::PARAM_STR);
	$sql->bindValue(":Total",  $fullRows["Total"]  , PDO::PARAM_INT);
	$sql->bindValue(":Date",  $fullRows["date"]  , PDO::PARAM_STR);
	$sql->bindValue(":InvoiceNo", $InvoiceNo  , PDO::PARAM_STR);
	$sql->execute();
  }

  function deletefromoldtable($sessionid)
  {
  $con = conn();
	$insert = "DELETE FROM sales where SessionId =:SessionId";
    $sql = $con->prepare($insert);
	$sql->bindValue(":SessionId", $sessionid);
	$sql->execute();
}



  $fetchCart =  $db_connection->prepare("select * from sales where SessionId =:SessionId");
	$fetchCart->bindValue(":SessionId", $_SESSION["session_id"]);
	$fetchCart->execute();
	$fullRows = $fetchCart->fetchAll(PDO::FETCH_ASSOC);



	$strShuffle = str_shuffle("ABCDEFGHIJKLMNOPQRSTVWZ");
	$strShuffle = substr($strShuffle, -2);
	$InvoiceNo = time().$strShuffle;

	foreach ($fullRows as $value) {
			 addToFinal($InvoiceNo, $value);
		}

		foreach ($fullRows as $value) {
			 deletefromoldtable($_SESSION["session_id"]);
		}
?>


<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/admin.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" href="http://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">

 <style type="text/css">

 </style>

</head>
<body onload="window.print()">

<div id="wrapper">


<div id="contents">

<?php
$fetchR = getFinal();
$InvoiceNo = $fetchR[0]["InvoiceNo"];
?>
INVOCE NUMBER  :::  <?php echo $InvoiceNo ; $grandtotal = 0 ; ?>
		<table class="table table-bordered">
		<tr><th>Drug Name</th><th>Price</th><th>Quantity</th><th>Total</th></tr>
		<?php foreach ($fetchR as $one) {
			$grandtotal = $grandtotal + $one["Total"] ?>
		<tr>
		<td class="colspace"><?php echo $one["DrugName"];?></td>
		<td><?php echo $one["Price"];?></td>
		<td><?php echo $one["Quantity"];?></td>
		<td><?php echo $one["Total"];?></td>
		</tr>



	<?php } ?>

</table>
Grand total ::: <?php echo $grandtotal; ?>

</div>
</div>

<script  src="js/jquery-3.1.1.min.js"></script>
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
