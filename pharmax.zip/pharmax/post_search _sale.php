<?php
	
	require_once 'dbconfig.php';

	
	$keyword = json_decode($_POST["data"]);
	$keyword = trim($keyword->values);
	if(strlen($keyword) == 0){
		die;
	}

	$sugg_json = array();    // this is for displaying json data as a autosearch suggestion
	$json_row = array();     // this is for stroring mysql results in json string
 

	$keyword = preg_replace('/\s+/', ' ', $keyword); // it will replace multiple spaces from the input.

	$query = 'SELECT DrugId, DrugName, Unit, Price FROM drugs WHERE DrugName LIKE :term'; // select query
	
	$stmt = $db_connection->prepare( $query );
	$stmt->execute(array(':term'=>"%$keyword%"));
	
	$sugg_json = $stmt->fetchAll();
	?>

	<table class="table table-bordered">
	<tr><td>Name</td><td>Price</td> <td>Quantity</td></tr>

		<?php foreach ($sugg_json  as  $value) {?>
			<tr><td class="colspace"><?php echo $value["DrugName"];?>
				
			</td>  <td><?php echo $value["Price"];?></td> 
			</td>  <td class="colqty"><input type="text" class="txtquqntity" id="<?php echo $value["DrugId"];?>" name=""></td> 
			 <td><img src="css/images/cart.png" onclick="addtocart('<?php echo $value["DrugId"];?>')" style="cursor: pointer;"></td>

			 </tr>
		<?php }?>
	</table>
	
	