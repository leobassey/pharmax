<?php
     session_start();
  
	require_once 'dbconfig.php';
	
	
	$data= json_decode($_POST["data"]);
	$drugid = $data->drugid;
	$qty = $data->qty;

	

	
	//get the information of the selected drug
	$query = 'SELECT DrugId, DrugName, Unit, Price FROM drugs WHERE DrugId LIKE :drugid'; // select query
	
	$stmt = $db_connection->prepare( $query );
	$stmt->bindValue(":drugid", $drugid, PDO::PARAM_INT);
	$stmt->execute();
	$row = $stmt->fetch(PDO::FETCH_ASSOC);
	$total = $row["Price"] * $qty;


    //insert into sales table
	$insert = "Insert into sales (DrugId, DrugName,  Price, Quantity, SessionId, Total, Date) values 
	(:DrugId, :DrugName,  :Price, :Quantity, :SessionId, :Total, :Date)";
    $sql = $db_connection->prepare($insert);
	$sql->bindValue(":DrugId", $drugid, PDO::PARAM_INT);
	$sql->bindValue(":DrugName", $row["DrugName"], PDO::PARAM_STR);
	$sql->bindValue(":Price", $row["Price"], PDO::PARAM_INT);
	$sql->bindValue(":Quantity", $qty, PDO::PARAM_INT);
	$sql->bindValue(":SessionId",  $_SESSION["session_id"]  , PDO::PARAM_STR);
	$sql->bindValue(":Total",  $total  , PDO::PARAM_INT);
	$sql->bindValue(":Date",  date("d-m-Y")  , PDO::PARAM_STR);
	$sql->execute();


	$fetchCart =  $db_connection->prepare("select * from sales where SessionId =:SessionId");
	$fetchCart->bindValue(":SessionId", $_SESSION["session_id"]);
	$fetchCart->execute();
	$fullRows = $fetchCart->fetchAll(PDO::FETCH_ASSOC);?>
	<table class="table table-bordered">
	<tr><th>Drug Name</th><th>Price</th><th>Quantity</th><th>Total</th><th></th></tr>
	<?php
	$grandtotal = 0;
	foreach ($fullRows as $value) {
		$grandtotal = $grandtotal + $value["Total"] ?>

	<tr>
	<td class="colspace"><?php echo $value["DrugName"];?></td>
	<td><?php echo $value["Price"];?></td> 
	<td><?php echo $value["Quantity"];?></td> 
	<td><?php echo $value["Total"];?></td> 
	<td><a href="javascript:void(0)" onclick="removeFromCart('<?php echo $value["Id"]?>')" style="cursor: pointer;" > <img src='css/icons/Cancel.gif'> </a> </td> 
	</tr>
		
	<?php  } ?>
<tr><td><b>Grand total : <?php echo $grandtotal;?></b><br>
<b>No of Items in cart (<?php echo count($fullRows); ?>)</b>
 <br/> <br/> <br/> 
 
<a href="processfinalsales.php" style="width: 100px; height: 45px; background-color:blue; text-decoration: none; padding-left: 10px">Process </a>
 
 </td></tr>

</table>

	
	
	