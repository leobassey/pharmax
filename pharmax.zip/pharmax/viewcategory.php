
<?php
require_once 'dbconfig.php';

if(isset($_GET['Id']) && !empty($_GET['Id']))
{
	//Get data from the form fields into variables

	$Id = trim($_GET['Id']);
	$stmt_edit = $db_connection->prepare('SELECT * from category where Id =:Id');
	$stmt_edit->bindValue(":Id", $Id, PDO::PARAM_STR);
	$stmt_edit->execute();
	$edit_row = $stmt_edit->fetch(PDO::FETCH_ASSOC);
	//var_dump($edit_row);

}

if(isset($_POST['save']))
{

	//Get data from the form fields into variables
	$name = filter_var($_POST['category'], FILTER_SANITIZE_STRING  );


		// If  there is no error update records in the database
		if(!isset($errorMessage))
		{

			$updateStatement = $db_connection->prepare('UPDATE category SET Name=:Name WHERE Id =:Id');

			$updateStatement->bindValue(':Id', $edit_row['Id'], PDO::PARAM_INT);
			$updateStatement->bindValue(':Name', $na, PDO::PARAM_STR);
			$updateStatement->bindValue(':DrugName', $drugName, PDO::PARAM_STR);
			$updateStatement->bindValue(':Unit', $unit, PDO::PARAM_INT);
			$updateStatement->bindValue(':Price', $price, PDO::PARAM_INT);

			if($updateStatement->execute())
			{
				?>
                <script>
				alert('drug updated successfully');

				window.location.href='viewdrug.php';
				</script>
                <?php
			}
			else
			{
				$errorMessage = "There was error trying to update records, please try again";
			}
		}
		}
?>



<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/admin.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">


	<style type="text/css">


input[type="button"]
{ width:100%; height:50px;transition: all 0.3s ease-in-out; transition: all 0.3s ease-in-out;
	border: 1px solid transparent;
	border-radius: 5px;
	margin-left: 4%;
	margin-top: 9px;
	padding: 15px;
	margin: 3px;
	background-color: #f6f8f8;

}
 .inputc
{
	margin-left: 4%;
	border: 1px solid #a8a8a8;
	border-radius: 5px;
	font-size: 30px;
	height: 40px;
	width: 95%;
	color: #a8a8a8;
}
.bgcolornumber{ background-color:#f1f1f1; color:#333; transition: all 0.3s ease-in-out;}
.bgclear{ background:#CC0000; color:#000;transition: all 0.3s ease-in-out;}
.bgoperationcolor{ background-color:#f6f8f8; color:#000; transition: all 0.3s ease-in-out;}
.equal{ background-color:#66CC33; color:#000; transition: all 0.3s ease-in-out;}
.bgcolornumber:hover{ background-color:#222; color:#f5f5f5;transition: all 0.3s ease-in-out;}
.bgclear:hover{background-color:#222; color:#f5f5f5;transition: all 0.3s ease-in-out;}
.bgoperationcolor:hover{ background-color:#222;; color:#f5f5f5;transition: all 0.3s ease-in-out;}
.equal:hover{ background-color:#222; color: #f5f5f5; transition: all 0.3s ease-in-out;}


</style>






	<script type="text/javascript">
function cals(buttonValue)
{
if (buttonValue == 'C')
{
   document.getElementById('valueshow').value = '0';
}
else
  {
    if(document.getElementById('valueshow').value == '0')
 {

   document.getElementById('valueshow').value = buttonValue;
}

  else
   {

    document.getElementById('valueshow').value += buttonValue;
   }
  }
 }
  function cal(equation)

  {
  var answer = eval(equation);
document.getElementById('valueshow').value = answer;
 }
 </script>

 <style type="text/css">
 .ps-btn{ border-radius:1px !important;}
 </style>

</head>
<body>
<?php
include('../pharmax/views/header.php')
 ?>

<div id="wrapper">

<?php
include('../pharmax/views/leftsidebar.php')
 ?>

<div id="contents">
<ul>

	<li><img src="css/icons/home.png"><a href="adddrug2.php">&nbsp; Add Drug >></a></li>
	<li><img src="css/icons/Edit.gif"><a href="viewdrug.php">&nbsp;View All </a></li>&nbsp;&nbsp;&nbsp;
	<li><img src="css/icons/settings.png"><a href="viewcategory.php">&nbsp;Edit category </a></li>
</ul>
    <p></p><p></p><p></p><p></p>

<br/><br/>
<p class="pview"> Drug Category</p>

	<br/>

	<?php

			$sql = "SELECT * from category";
			$query = $db_connection->prepare($sql);
			$query->execute();
			$results = $query->fetchAll(PDO::FETCH_ASSOC);
	?>

<table class="table table-bordered table-responsive">

	<tr>
			<th >Id</th>
			<th>Name</th>


			<th><strong>Edit</strong></th>



	</tr>


 <?php foreach( $results as $row )
 {
 	?>
   		<tr>


     	<td> <?php  echo $row['Id'] ?></td>

     	<td> <?php echo $row['Name'];?></td>


       	<td><a href='editcategory.php?Id=<?php echo $row["Id"]?>'> <img src='css/icons/Edit.gif'> </a></td>



   		</tr>

  <?php
}

 ?>


</table>

</div>

<div id="editcategory" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Add New Category</h4>
            </div>
             <form action="catadd.php" method="POST">
            <div class="modal-body">
                <p>Edit drug category and click on add to return to category page</p>

                	<label for="catname">Category Name</label>
                	<input type="text" name="catname" placeholder="Enter category e.g Protein, Vitamin etc" required="text" class="ttext" />
                	<br><br>
                	 <input type="submit" type="button" class="btn btn-primary" name="catadd" value="Add"/>
                	  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>

            </div>
            </form>
            <div class="modal-footer">


            </div>
        </div>
    </div>
</div>

<?php
include('../pharmax/views/rightsidebar.php')
 ?>
</div>
<script src="js/jquery-3.1.1.min.js"></script>

<script src="js/bootstrap.js"></script>
<div id="footer">pharmaX (c) 2017. All right reserved. Powered by <a href="#">Memdal Solutions</a></div>
</body>
</html>
