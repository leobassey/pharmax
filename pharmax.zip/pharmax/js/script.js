function formValid(eventObj) {
if (document.forms["form"].txtUserName.value.length == 0) {
alert("Name is required.");
if (eventObj.preventDefault) {
eventObj.preventDefault();
} else {
window.event.returnValue = false;
}
return false;
} else {
alert("Hello " + document.forms["form"].txtUserName.value);
return true;
}
}


/**function CheckData()
{
	var userName = document.getElementById("txtUserName");
	alert(userName);
}
**/